/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Labourrequest;
import model.Register;
import model.Userrequest;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Dell
 */
public class labourrequest extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
             HttpSession hs = request.getSession();
            /* TODO output your page here. You may use following sample code. */
            Session s = NewHibernateUtil.getSessionFactory().openSession();
            Session s1 = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t = s.beginTransaction();
            Transaction t1 = s1.beginTransaction();
            Criteria c = s.createCriteria(Labourrequest.class);
            Criteria c1 = s1.createCriteria(Userrequest.class);
              int request_id = Integer.parseInt(request.getParameter("rq"));
            c.add(Restrictions.eq("labourreqid",request_id));
            int urid =(Integer.parseInt(request.getParameter("urid").toString()));
            hs.setAttribute("userid", urid);
            ArrayList<Labourrequest> al =( ArrayList<Labourrequest>) c.list();
            
            Labourrequest llrr = al.get(0);
            int rerid = llrr.getRerid().getRerid();
             c1.add(Restrictions.eq("rerid",rerid));
              ArrayList<Userrequest> ul =( ArrayList<Userrequest>) c1.list();
              Userrequest ur = ul.get(0);
            int o = Integer.parseInt(request.getParameter("o").toString());
            request.setAttribute("o", o);
            if(o==1)
            {
                llrr.setAccpet("Accept");
                 ur.setAccept("Accept");
            }
            else
            {
                llrr.setAccpet("Decline");
                 ur.setAccept("Decline");
            }
           
            s.save(llrr);
            s1.save(ur);
            t.commit();
            t1.commit();
            //RequestDispatcher rd = request.getRequestDispatcher("labourrequest.jsp");
             RequestDispatcher rd = request.getRequestDispatcher("emailsend");
            rd.forward(request, response);
        }catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
