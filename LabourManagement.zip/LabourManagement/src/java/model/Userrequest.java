/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dell
 */
@Entity
@Table(name = "userrequest")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Userrequest.findAll", query = "SELECT u FROM Userrequest u"),
    @NamedQuery(name = "Userrequest.findByRerid", query = "SELECT u FROM Userrequest u WHERE u.rerid = :rerid"),
    @NamedQuery(name = "Userrequest.findByCategory", query = "SELECT u FROM Userrequest u WHERE u.category = :category"),
    @NamedQuery(name = "Userrequest.findByReqfullfill", query = "SELECT u FROM Userrequest u WHERE u.reqfullfill = :reqfullfill"),
    @NamedQuery(name = "Userrequest.findByAccept", query = "SELECT u FROM Userrequest u WHERE u.accept = :accept")})
public class Userrequest implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "rerid")
    private Integer rerid;
    @Basic(optional = false)
    @Column(name = "category")
    private String category;
    @Basic(optional = false)
    @Column(name = "reqfullfill")
    private String reqfullfill;
    @Column(name = "accept")
    private String accept;
    @JoinColumn(name = "urid", referencedColumnName = "rid")
    @ManyToOne(optional = false)
    private Register urid;
    @JoinColumn(name = "lrid", referencedColumnName = "rid")
    @ManyToOne(optional = false)
    private Register lrid;

    public Userrequest() {
    }

    public Userrequest(Integer rerid) {
        this.rerid = rerid;
    }

    public Userrequest(Integer rerid, String category, String reqfullfill) {
        this.rerid = rerid;
        this.category = category;
        this.reqfullfill = reqfullfill;
    }

    public Integer getRerid() {
        return rerid;
    }

    public void setRerid(Integer rerid) {
        this.rerid = rerid;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getReqfullfill() {
        return reqfullfill;
    }

    public void setReqfullfill(String reqfullfill) {
        this.reqfullfill = reqfullfill;
    }

    public String getAccept() {
        return accept;
    }

    public void setAccept(String accept) {
        this.accept = accept;
    }

    public Register getUrid() {
        return urid;
    }

    public void setUrid(Register urid) {
        this.urid = urid;
    }

    public Register getLrid() {
        return lrid;
    }

    public void setLrid(Register lrid) {
        this.lrid = lrid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rerid != null ? rerid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userrequest)) {
            return false;
        }
        Userrequest other = (Userrequest) object;
        if ((this.rerid == null && other.rerid != null) || (this.rerid != null && !this.rerid.equals(other.rerid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Userrequest[ rerid=" + rerid + " ]";
    }
    
}
