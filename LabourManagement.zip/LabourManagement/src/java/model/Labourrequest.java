/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dell
 */
@Entity
@Table(name = "labourrequest")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Labourrequest.findAll", query = "SELECT l FROM Labourrequest l"),
    @NamedQuery(name = "Labourrequest.findByLabourreqid", query = "SELECT l FROM Labourrequest l WHERE l.labourreqid = :labourreqid"),
    @NamedQuery(name = "Labourrequest.findByAccpet", query = "SELECT l FROM Labourrequest l WHERE l.accpet = :accpet"),
    @NamedQuery(name = "Labourrequest.findByFullfill", query = "SELECT l FROM Labourrequest l WHERE l.fullfill = :fullfill")})
public class Labourrequest implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "labourreqid")
    private Integer labourreqid;
    @Basic(optional = false)
    @Column(name = "accpet")
    private String accpet;
    @Basic(optional = false)
    @Column(name = "fullfill")
    private String fullfill;
    @JoinColumn(name = "lrid", referencedColumnName = "rid")
    @ManyToOne(optional = false)
    private Register lrid;
    @JoinColumn(name = "urid", referencedColumnName = "rid")
    @ManyToOne(optional = false)
    private Register urid;
    @JoinColumn(name = "rerid", referencedColumnName = "rerid")
    @ManyToOne(optional = false)
    private Userrequest rerid;

    public Labourrequest() {
    }

    public Labourrequest(Integer labourreqid) {
        this.labourreqid = labourreqid;
    }

    public Labourrequest(Integer labourreqid, String accpet, String fullfill) {
        this.labourreqid = labourreqid;
        this.accpet = accpet;
        this.fullfill = fullfill;
    }

    public Integer getLabourreqid() {
        return labourreqid;
    }

    public void setLabourreqid(Integer labourreqid) {
        this.labourreqid = labourreqid;
    }

    public String getAccpet() {
        return accpet;
    }

    public void setAccpet(String accpet) {
        this.accpet = accpet;
    }

    public String getFullfill() {
        return fullfill;
    }

    public void setFullfill(String fullfill) {
        this.fullfill = fullfill;
    }

    public Register getLrid() {
        return lrid;
    }

    public void setLrid(Register lrid) {
        this.lrid = lrid;
    }

    public Register getUrid() {
        return urid;
    }

    public void setUrid(Register urid) {
        this.urid = urid;
    }

    public Userrequest getRerid() {
        return rerid;
    }

    public void setRerid(Userrequest rerid) {
        this.rerid = rerid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (labourreqid != null ? labourreqid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Labourrequest)) {
            return false;
        }
        Labourrequest other = (Labourrequest) object;
        if ((this.labourreqid == null && other.labourreqid != null) || (this.labourreqid != null && !this.labourreqid.equals(other.labourreqid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Labourrequest[ labourreqid=" + labourreqid + " ]";
    }
    
}
