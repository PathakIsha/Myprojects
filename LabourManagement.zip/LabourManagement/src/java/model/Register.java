/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dell
 */
@Entity
@Table(name = "register")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Register.findAll", query = "SELECT r FROM Register r"),
    @NamedQuery(name = "Register.findByRid", query = "SELECT r FROM Register r WHERE r.rid = :rid"),
    @NamedQuery(name = "Register.findByFirstname", query = "SELECT r FROM Register r WHERE r.firstname = :firstname"),
    @NamedQuery(name = "Register.findByLastname", query = "SELECT r FROM Register r WHERE r.lastname = :lastname"),
    @NamedQuery(name = "Register.findByCategory", query = "SELECT r FROM Register r WHERE r.category = :category"),
    @NamedQuery(name = "Register.findByMobileno", query = "SELECT r FROM Register r WHERE r.mobileno = :mobileno"),
    @NamedQuery(name = "Register.findByAddress", query = "SELECT r FROM Register r WHERE r.address = :address"),
    @NamedQuery(name = "Register.findByType", query = "SELECT r FROM Register r WHERE r.type = :type"),
    @NamedQuery(name = "Register.findByPrice", query = "SELECT r FROM Register r WHERE r.price = :price"),
    @NamedQuery(name = "Register.findByImageurl", query = "SELECT r FROM Register r WHERE r.imageurl = :imageurl")})
public class Register implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id@GeneratedValue
    @Basic(optional = false)
    @Column(name = "rid")
    private Integer rid;
    @Basic(optional = false)
    @Column(name = "firstname")
    private String firstname;
    @Basic(optional = false)
    @Column(name = "lastname")
    private String lastname;
    @Basic(optional = false)
    @Column(name = "category")
    private String category;
    @Basic(optional = false)
    @Column(name = "mobileno")
    private String mobileno;
    @Column(name = "address")
    private String address;
    @Basic(optional = false)
    @Column(name = "type")
    private String type;
    @Column(name = "price")
    private Integer price;
    @Column(name = "imageurl")
    private String imageurl;

    public Register() {
    }

    public Register(Integer rid) {
        this.rid = rid;
    }

    public Register(Integer rid, String firstname, String lastname, String category, String mobileno, String type) {
        this.rid = rid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.category = category;
        this.mobileno = mobileno;
        this.type = type;
    }

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rid != null ? rid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Register)) {
            return false;
        }
        Register other = (Register) object;
        if ((this.rid == null && other.rid != null) || (this.rid != null && !this.rid.equals(other.rid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Register[ rid=" + rid + " ]";
    }
    
}
