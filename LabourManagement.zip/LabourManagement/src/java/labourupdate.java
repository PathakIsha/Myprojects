/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Login;
import model.Register;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Dell
 */
public class labourupdate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            HttpSession hs =request.getSession();
            
            Register rid = (Register)hs.getAttribute("rid");
            int rrid = rid.getRid();
            String fn = request.getParameter("fn");
            String mob = request.getParameter("mob");
            String pass = request.getParameter("password");
            String repass= request.getParameter("repassword");
            String address = request.getParameter("address");
            
            Session s = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t = s.beginTransaction();
            Session s1 = NewHibernateUtil.getSessionFactory().openSession();
            Transaction t1 = s1.beginTransaction();
            Criteria c = s.createCriteria(Login.class);
            Criteria c1 = s1.createCriteria(Register.class);
            c1.add(Restrictions.eq("rid", rrid));
            c.add(Restrictions.eq("rid", rid));
            ArrayList<Register> al = (ArrayList<Register>)c1.list();
            ArrayList<Login> ll = (ArrayList<Login>)c.list();
            if((al.size()>0) && (pass.equals(repass)) && (ll.size()>0))
            {
                Register r = al.get(0);
                r.setAddress(address);
                r.setFirstname(fn);
                r.setMobileno(mob);
                Login l = ll.get(0);
                l.setPassword(pass);
                s.save(l);
                s1.save(r);
                t.commit();
                t1.commit();
                 RequestDispatcher rd = request.getRequestDispatcher("labourprofile");
                rd.forward(request, response);
            }
            else
            {
                RequestDispatcher rd = request.getRequestDispatcher("labourupdate.jsp");
                rd.forward(request, response);
            }
        }catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
